$(document).ready(function(){
	$(".menu li a").mouseover(
		function() {
			$(this).css({'color':'#ffac7a'});
		}
	);
	$(".menu li a").mouseleave(
		function() {
			$(this).css({'color':'#978a7c'});
		}
	);
	$(".menu li a").click(
		function(){
			//alert($(this).parent().attr('id'));		
			switch($(this).parent().attr('id')){
			case 'opthome':
				window.location.assign("erreeme.html");
			    return false;  // Prevent the browser from folowing the href link
				break;
			case 'optempresa':
				window.location.assign('erreeme.empresa.html');
				return false;  // Prevent the browser from folowing the href link
				break;
			case 'optambientes':
				window.location.assign("erreeme.ambientes.html");
				return false;  // Prevent the browser from folowing the href link
				break;
			case 'optcontactos':
				window.location.assign("erreeme.contactos.html");
				return false;
				break;
			case 'optparcerias':
				window.location.assign("erreeme.parcerias.html");
				return false;
				break;
			case 'optcoleccao':
				window.location.assign("erreeme.coleccao.html");
				return false;
				break;
			}
		}
	);
	$(".language").click(
		function(){
			//alert($(this).attr('id'));
			switch($(this).attr('id')){
			case 'langde':
				window.location.assign("erreeme.php?lang=de");
			break;
			case 'langpt':
				window.location.assign("erreeme.empresa.html");
			break;
			}
		}
	);
	$(".amostras img").mouseenter(
		function(e){
			cursor=getMousePosition(e);
			$(".amostraszoom img").attr('src',$(this).attr('src'));
			$(".amostraszoom").css('left',cursor.x-90);
			$(".amostraszoom").show();
			//alert($(this).attr('src')+'('+cursor.x+','+cursor.y+')');
		}
	);
	$(".amostras img").mouseleave(
		function(){
			$(".amostraszoom").hide();
		}
	);
});