<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html lang="pt-PT">
<head>
	<title>erreeme</title>
	<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
	<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE8">
	<meta http-equiv="Content-Style-Type" CONTENT="text/css">
	<meta http-equiv="Content-Script-Type" CONTENT="text/javascript">
	<meta name="keywords" content="erreeme, tapetes, tape�arias, rugs">
	<meta name="robots" content="all">
	<link rel="shortcut icon" href="img/logos/erreeme.ico" type="image/x-icon">
	<!-- IMPORT STYLESHEETS																 -->
	<!-- media="all,print,handheld"                                                      -->
	<link rel="stylesheet" type="text/css" media="all" href="erreeme.css">
	<!-- IMPORT JAVASCRIPT																 -->
</head>
<body>
<?php
	scho Obrigado pela Inscricao. Vai receber a confirmacoo no seu e-mail.\n
	echo $_POST["email"];

	//$to = "geral@erreeme.pt";
	$to = "paulo.alexandre.romualdo@gmail.com"
	$subject = "Confirma��o de Registo da Newsletter de RM Custom Rugs";
	$message = "Obrigado pela sua inscri��o.\n o endere�o ".$_POST["email"]." foi registado com sucesso";
	$from = "newsletter@erreeme.pt";
	$headers = "From:" . $from;
	mail($to,$subject,$message,$headers);
	//echo "Mail Sent.";
?>
</body>
</html>