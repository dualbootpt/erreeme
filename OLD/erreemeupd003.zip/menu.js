$(document).ready(function(){
	$(".menu li a").mouseover(
		function() {
			$(this).css({'color':'#ffac7a'});
		}
	);
	$(".menu li a").mouseleave(
		function() {
			$(this).css({'color':'#978a7c'});
			$(".menu a.selected").css('color','#ffac7a');
		}
	);
	$(".menu li a").click(
		function(){
			//console.log($(this).parent().attr('id'));
			switch($(this).parent().attr('id')){
			case 'opthome':
				window.location.assign("erreeme.html");
			    return false;  // Prevent the browser from folowing the href link
				break;
			case 'optempresa':
				window.location.assign('erreeme.empresa.html');
				return false;  // Prevent the browser from folowing the href link
				break;
			case 'optambientes':
				window.location.assign("erreeme.ambientes.html");
				return false;  // Prevent the browser from folowing the href link
				break;
			case 'optcontactos':
				window.location.assign("erreeme.contactos.html");
				return false;
				break;
			case 'optparcerias':
				window.location.assign("erreeme.parcerias.html");
				return false;
				break;
			case 'optcoleccao':
				window.location.assign("erreeme.coleccao.html");
				return false;
				break;
			}
		}
	);
	$(".language").click(
		function(){
			//console.log($(this).attr('id'));
			switch($(this).attr('id')){
			case 'langde':
				window.location.assign("erreeme.php?lang=de");
			break;
			case 'langpt':
				window.location.assign("erreeme.empresa.html");
			break;
			}
		}
	);
	$(".coleccao .qualidades img, .coleccao .leftside img").click(
		function(){
			//console.log($(this).attr('bannerslide'));
			mostraColeccao($(this).attr('bannerslide'));
		}
	);	
	$(".amostras").mouseenter(
		function(){
			$(".amostraszoom").show();
			//console.log('Entrou');
		}
	);
	$(".amostras").mouseleave(
		function(){
			$(".amostraszoom").hide();
			//console.log('Saiu');
		}
	);	
	$(".amostras img").mouseenter(
		function(e){
			//console.log('entrou');
				cursor=getMousePosition(e);
				if($(this).attr('src') != $(".amostraszoom img").attr('src'))
					$(".amostraszoom img").attr('src',$(this).attr('src'));
				//console.log(cursor.x,' ; ',cursor.y);
				$(".amostraszoom").css('left',cursor.x-90);
				$(".amostraszoom").show();
				//console.log($(this).attr('src')+'('+cursor.x+','+cursor.y+')');
		}
	);
	$(".amostras img").click(
		function(e){
				cursor=getMousePosition(e);
				$(".amostraszoom img").attr('src',$(this).attr('src'));
				$(".amostraszoom").css('left',cursor.x-90);
				$(".amostraszoom").show();
				//console.log($(this).attr('src')+'('+cursor.x+','+cursor.y+')');
		}
	);	
	$(".amostras img").mouseleave(
		function(){
			//console.log('saiu');
			$(".amostraszoom").hide();
			entrou = false;
		}
	);
	$(".leftside #down").click(
		function(){
			//console.log($(".Vbanner img:visible").length);
			if($(".Vbanner img:visible").length > 5) {
				$(".Vbanner img:visible:first").toggle();
			}
			//console.log($(".Vbanner img:visible:first").attr('bannerslide'));
		}	
	);
	$(".leftside #up").click(
		function(){
			//console.log($(".Vbanner img:visible").length);
			$(".Vbanner img:not(':visible'):last").toggle();
			//console.log($(".Vbanner img:not(':visible'):last").attr('bannerslide'));
		}
	);	
});

function mostraColeccao(id){
	$(".coleccao .textblock").hide();
	$(".coleccao .qualidades").hide();
	$(".coleccao .amostras").show();
	$(".coleccao .leftside").css('display','inline-block');
	$(".coleccao .bannerswindow").css('display','inline-block');
	$(".coleccao .leftside img").css('opacity','1');
	$(".coleccao .Vbanner img").eq(parseInt(id)-1).css('opacity','.5');
	//console.log(id);
}