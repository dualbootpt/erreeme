<?php
	// http://www.raelcunha.com/template.php
	require("Template.class.php");
	
	$tpl = new Template("erreeme.contactos.html");
	$tpl->LANGUAGE = $_GET['lang'];
	$tpl->RIGHTSIDETEXTBLOCK = "Os nossos padr�es de qualidade, resultam da utiliza��o dos melhores materiais como,
								seda, mohair, linho e l�, na produ��o dos nossos tapetes. O conforto, a inova��o e a
								supera��o, s�o fatores decisivos na nossa atua��o."
	
	$menu = array(
				"LINGUA" => "LINGUA",
				"EMPRESA" => "EMPRESA",
				"COLECCAO" => "COLEC&Ccedil&AtildeO",
				"AMBIENTES" => "AMBIENTES",
				"CONTACTOS" => "CONTACTOS",
				"PARCERIAS" => "PARCERIAS"
			);
	
	$tpl->LINGUA = $menu["LINGUA"];
	$tpl->EMPRESA = $menu["EMPRESA"];
	$tpl->COLECCAO = $menu["COLECCAO"];
	$tpl->AMBIENTES = $menu["AMBIENTES"];
	$tpl->CONTACTOS = $menu["CONTACTOS"];
	$tpl->PARCERIAS = $menu["PARCERIAS"];
	
	$tpl->show();
?>