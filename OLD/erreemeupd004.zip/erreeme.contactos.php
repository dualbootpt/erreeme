<?php
	// http://www.raelcunha.com/template.php
	require("Template.class.php");
	
	$tpl = new Template("erreeme.contactos.html");
	$tpl->LANGUAGE = $_GET['lang'];
	
	$menu = array(
				"LINGUA" => "LINGUA",
				"EMPRESA" => "EMPRESA",
				"COLECCAO" => "COLEC&Ccedil&AtildeO",
				"AMBIENTES" => "AMBIENTES",
				"CONTACTOS" => "CONTACTOS",
				"PARCERIAS" => "PARCERIAS"
			);
	
	$tpl->LINGUA = $menu["LINGUA"];
	$tpl->EMPRESA = $menu["EMPRESA"];
	$tpl->COLECCAO = $menu["COLECCAO"];
	$tpl->AMBIENTES = $menu["AMBIENTES"];
	$tpl->CONTACTOS = $menu["CONTACTOS"];
	$tpl->PARCERIAS = $menu["PARCERIAS"];
	
	$tpl->show();
?>