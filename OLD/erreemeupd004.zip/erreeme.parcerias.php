<?php
	// http://www.raelcunha.com/template.php
	require("Template.class.php");
	
	$tpl = new Template("erreeme.contactos.html");
	$tpl->LANGUAGE = $_GET['lang'];
	$tpl->TOPBLOCKTEXTBLOCK = "Estamos constantemente � procura de novos parceiros de neg�cio,
								para continuar a levar aos nossos clientes um servi�o completo e de qualidade.
								<p>
								Se estiver interessado em colaborar connosco, por favor <a href="mailto:geral@erreeme.pt">contacte-nos</a>.
							   "
	
	$menu = array(
				"LINGUA" => "LINGUA",
				"EMPRESA" => "EMPRESA",
				"COLECCAO" => "COLEC&Ccedil&AtildeO",
				"AMBIENTES" => "AMBIENTES",
				"CONTACTOS" => "CONTACTOS",
				"PARCERIAS" => "PARCERIAS"
			);
	
	$tpl->LINGUA = $menu["LINGUA"];
	$tpl->EMPRESA = $menu["EMPRESA"];
	$tpl->COLECCAO = $menu["COLECCAO"];
	$tpl->AMBIENTES = $menu["AMBIENTES"];
	$tpl->CONTACTOS = $menu["CONTACTOS"];
	$tpl->PARCERIAS = $menu["PARCERIAS"];
	
	$tpl->show();
?>